=== Third PARTY URL ===
Contributors: ketanumretiya030
Donate link: https://www.paypal.me/KUmretiya
Tags: comments, spam
Requires at least: 4
Tested up to: 4.9.2
Requires PHP: 5.2.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Third party url plugin chek all link in site if any link found thirdparty yhen it will automatik open in new window.

